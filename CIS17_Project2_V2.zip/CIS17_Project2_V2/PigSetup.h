/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PigSetup.h
 * Author: wyatt
 *
 * Created on December 16, 2022, 6:10 PM
 */

#ifndef PIGSETUP_H
#define PIGSETUP_H

#include <cstring>
#include <string>
#include <iostream>
using namespace std;
class Pers
{
    
public:
    

    string name="default";
    string title="unranked";
};
class PlayInf{
private:
    string win;

public:
    

    


    int* chDiff;

   
   
    int bravery;
    int turn;
    int NumYes;
    int NumNos;
    int Numtimes;
    float YesPerc;
    float NoPerc;
    bool result;
    Pers personal;
    
    void setwin(string);
    string getwin ()const; 
};
 



class message{
public:
    message();
    message (bool z);
    ~message();
};

class points{
public:
    
    int scores[400];
     int numturn=0;
};

class guess {
private:
    int x;
  
public:
    guess(int x1)
    {
        x = x1;
    
    }
  
    // Copy constructor
    guess(const guess& p1)
    {
        x = p1.x;
    
    }
  
    int getX() { return x; }
   
};

#endif /* PIGSETUP_H */

