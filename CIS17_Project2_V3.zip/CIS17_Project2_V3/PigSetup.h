/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PigSetup.h
 * Author: wyatt
 *
 * Created on December 16, 2022, 6:10 PM
 */

#ifndef PIGSETUP_H
#define PIGSETUP_H

#include <cstring>
#include <string>
#include <iostream>
using namespace std;
class Pers
{
    
public:
    

    string name="default";
    string title="unranked";
};
class PlayInf{
protected:
    string win;

public:
    

    


    int* chDiff;

   
   
    int bravery;
    int turn;
    int NumYes;
    int NumNos;
    int Numtimes;
    float YesPerc;
    float NoPerc;
    bool result;
    Pers personal;
    
    void setwin(string);
    string getwin ()const; 
};
 



class message{
public:
    message();
    message (bool z);
    ~message();
};

class points{
public:
    
    int scores[400];
     int numturn=0;
};

class guess {
private:
    int x;
  
public:
    guess(int x1)
    {
        x = x1;
    
    }
  
    // Copy constructor
    guess(const guess& p1)
    {
        x = p1.x; 
    }
    int getX() { return x; }
   
};

class Totality {
private:
    int xS;
public:
    Totality(int r = 0) {xS= r;}
     
    // This is automatically called when '+' is used with
    // between the objects
    Totality operator + (Totality const &obj) {
         Totality totalS;
         totalS.xS= xS + obj.xS;
        
         return totalS;
    }
    void print() { cout<<"The two scores combined equal:"<<xS<<endl; }
};
#endif /* PIGSETUP_H */

