/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PigSetup.cpp
 * Author: wyatt
 *
 * Created on December 16, 2022, 6:48 PM
 */

#include <cstdlib>
#include "PigSetup.h"
#include <iostream>
using namespace std;



void PlayInf::setwin(string w){
    win=w;
}

string PlayInf::getwin ()const{
    return win;
}
message::message(){
    cout<<"Welcome to my Project 2! This is a constructor in my Project. Hope you enjoy the game."<<endl;
}


message::message(bool z){
    if (z==true){
        cout<<"Hope you had fun!"<<endl; 
    }
}
message::~message(){
    cout<<"this is my destructor. by the way...Is it groundhogs day?"<<endl;
}
